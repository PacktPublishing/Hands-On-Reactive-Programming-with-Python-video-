Observable.just(a,b,c,d);


