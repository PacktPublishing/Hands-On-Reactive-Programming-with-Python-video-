
/*example about just() operator*/
Observable.just(a,b,c,d);


