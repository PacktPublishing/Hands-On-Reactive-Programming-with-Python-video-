
/*here example of filter operator*/

Subject.filter( lambda text: not text or len(text) > 2 )
