 # Subject is Observable and Observer at the same time
self.subject = Subject()
user_input = self.subject.throttle_last(
    1000  # Receive the last value at a given time interval
).start_with(
    ''  # Sends a default value just after subscription
).filter(
    lambda text: len(text) == 0 or len(text) > 2
).distinct_until_changed()  # Only if the value has changed
